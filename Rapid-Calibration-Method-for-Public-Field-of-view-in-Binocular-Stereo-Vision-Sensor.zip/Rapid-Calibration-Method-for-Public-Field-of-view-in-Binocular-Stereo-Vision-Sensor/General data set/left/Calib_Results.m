% Intrinsic and Extrinsic Camera Parameters
%
% This script file can be directly executed under Matlab to recover the camera intrinsic and extrinsic parameters.
% IMPORTANT: This file contains neither the structure of the calibration objects nor the image coordinates of the calibration points.
%            All those complementary variables are saved in the complete matlab data file Calib_Results.mat.
% For more information regarding the calibration model visit http://www.vision.caltech.edu/bouguetj/calib_doc/


%-- Focal length:
fc = [ 527.167937130809260 ; 525.859979534882310 ];

%-- Principal point:
cc = [ 306.889621278847470 ; 251.129262790448450 ];

%-- Skew coefficient:
alpha_c = 0.000000000000000;

%-- Distortion coefficients:
kc = [ 0.149945732088437 ; -0.154836478659240 ; -0.000556385569206 ; 0.005020607365964 ; 0.000000000000000 ];

%-- Focal length uncertainty:
fc_error = [ 23.282680772732032 ; 23.261418980967175 ];

%-- Principal point uncertainty:
cc_error = [ 14.987578596989172 ; 7.350164849002479 ];

%-- Skew coefficient uncertainty:
alpha_c_error = 0.000000000000000;

%-- Distortion coefficients uncertainty:
kc_error = [ 0.020961909784882 ; 0.026418217082014 ; 0.003622042633349 ; 0.006052774588861 ; 0.000000000000000 ];

%-- Image size:
nx = 640;
ny = 480;


%-- Various other variables (may be ignored if you do not use the Matlab Calibration Toolbox):
%-- Those variables are used to control which intrinsic parameters should be optimized

n_ima = 4;						% Number of calibration images
est_fc = [ 1 ; 1 ];					% Estimation indicator of the two focal variables
est_aspect_ratio = 1;				% Estimation indicator of the aspect ratio fc(2)/fc(1)
center_optim = 1;					% Estimation indicator of the principal point
est_alpha = 0;						% Estimation indicator of the skew coefficient
est_dist = [ 1 ; 1 ; 1 ; 1 ; 0 ];	% Estimation indicator of the distortion coefficients


%-- Extrinsic parameters:
%-- The rotation (omc_kk) and the translation (Tc_kk) vectors for every calibration image and their uncertainties

%-- Image #1:
omc_1 = [ 2.110028e+00 ; 1.892425e+00 ; 1.930633e-01 ];
Tc_1  = [ -3.308409e+02 ; 9.440014e+01 ; 5.938539e+02 ];
omc_error_1 = [ 1.514970e-02 ; 1.478155e-02 ; 2.104400e-02 ];
Tc_error_1  = [ 1.844360e+01 ; 8.714176e+00 ; 2.641658e+01 ];

%-- Image #2:
omc_2 = [ 1.816717e+00 ; 1.896363e+00 ; 4.214509e-01 ];
Tc_2  = [ -3.001164e+02 ; -2.474172e+02 ; 5.612165e+02 ];
omc_error_2 = [ 1.674630e-02 ; 1.881941e-02 ; 1.982215e-02 ];
Tc_error_2  = [ 1.778141e+01 ; 8.335709e+00 ; 2.444658e+01 ];

%-- Image #3:
omc_3 = [ 1.901961e+00 ; 2.179154e+00 ; 4.986347e-02 ];
Tc_3  = [ 1.755018e+00 ; -1.578770e+02 ; 7.084987e+02 ];
omc_error_3 = [ 1.143934e-02 ; 1.473717e-02 ; 2.689304e-02 ];
Tc_error_3  = [ 2.006830e+01 ; 9.745274e+00 ; 3.063743e+01 ];

%-- Image #4:
omc_4 = [ 1.953350e+00 ; 2.030401e+00 ; 2.927793e-01 ];
Tc_4  = [ -5.650287e+01 ; 1.232891e+02 ; 6.915463e+02 ];
omc_error_4 = [ 1.416084e-02 ; 1.215087e-02 ; 2.328045e-02 ];
Tc_error_4  = [ 1.996277e+01 ; 1.000042e+01 ; 3.133284e+01 ];

