% Intrinsic and Extrinsic Camera Parameters
%
% This script file can be directly executed under Matlab to recover the camera intrinsic and extrinsic parameters.
% IMPORTANT: This file contains neither the structure of the calibration objects nor the image coordinates of the calibration points.
%            All those complementary variables are saved in the complete matlab data file Calib_Results.mat.
% For more information regarding the calibration model visit http://www.vision.caltech.edu/bouguetj/calib_doc/


%-- Focal length:
fc = [ 527.148334641692940 ; 527.671980672982950 ];

%-- Principal point:
cc = [ 290.272762896154630 ; 240.733371996716950 ];

%-- Skew coefficient:
alpha_c = 0.000000000000000;

%-- Distortion coefficients:
kc = [ 0.139754297115713 ; -0.151215255958386 ; -0.001185923900505 ; -0.002813365850644 ; 0.000000000000000 ];

%-- Focal length uncertainty:
fc_error = [ 26.985521918310610 ; 27.574730413944774 ];

%-- Principal point uncertainty:
cc_error = [ 12.086011361945237 ; 4.228776387371974 ];

%-- Skew coefficient uncertainty:
alpha_c_error = 0.000000000000000;

%-- Distortion coefficients uncertainty:
kc_error = [ 0.016237469690505 ; 0.017980829679656 ; 0.002468401444448 ; 0.004013530228988 ; 0.000000000000000 ];

%-- Image size:
nx = 640;
ny = 480;


%-- Various other variables (may be ignored if you do not use the Matlab Calibration Toolbox):
%-- Those variables are used to control which intrinsic parameters should be optimized

n_ima = 4;						% Number of calibration images
est_fc = [ 1 ; 1 ];					% Estimation indicator of the two focal variables
est_aspect_ratio = 1;				% Estimation indicator of the aspect ratio fc(2)/fc(1)
center_optim = 1;					% Estimation indicator of the principal point
est_alpha = 0;						% Estimation indicator of the skew coefficient
est_dist = [ 1 ; 1 ; 1 ; 1 ; 0 ];	% Estimation indicator of the distortion coefficients


%-- Extrinsic parameters:
%-- The rotation (omc_kk) and the translation (Tc_kk) vectors for every calibration image and their uncertainties

%-- Image #1:
omc_1 = [ -2.382428e+00 ; -1.813882e+00 ; 4.527182e-01 ];
Tc_1  = [ -1.274992e+02 ; 1.078299e+02 ; 7.283071e+02 ];
omc_error_1 = [ 1.173942e-02 ; 7.748149e-03 ; 2.292368e-02 ];
Tc_error_1  = [ 1.638260e+01 ; 5.869588e+00 ; 3.779927e+01 ];

%-- Image #2:
omc_2 = [ 2.331568e+00 ; 2.044666e+00 ; -1.135518e-01 ];
Tc_2  = [ -1.882933e+02 ; -2.286407e+02 ; 6.776572e+02 ];
omc_error_2 = [ 6.342317e-03 ; 7.897949e-03 ; 1.941032e-02 ];
Tc_error_2  = [ 1.539704e+01 ; 5.380440e+00 ; 3.441842e+01 ];

%-- Image #3:
omc_3 = [ -2.048949e+00 ; -2.000536e+00 ; 4.794443e-01 ];
Tc_3  = [ 1.540018e+02 ; -2.073832e+02 ; 6.325058e+02 ];
omc_error_3 = [ 1.231090e-02 ; 1.001787e-02 ; 2.663379e-02 ];
Tc_error_3  = [ 1.468961e+01 ; 5.145571e+00 ; 3.190250e+01 ];

%-- Image #4:
omc_4 = [ -2.253827e+00 ; -1.948618e+00 ; 2.769724e-01 ];
Tc_4  = [ 1.550819e+02 ; 7.992477e+01 ; 6.557191e+02 ];
omc_error_4 = [ 8.013325e-03 ; 9.614001e-03 ; 1.718329e-02 ];
Tc_error_4  = [ 1.520224e+01 ; 5.317101e+00 ; 3.403204e+01 ];

