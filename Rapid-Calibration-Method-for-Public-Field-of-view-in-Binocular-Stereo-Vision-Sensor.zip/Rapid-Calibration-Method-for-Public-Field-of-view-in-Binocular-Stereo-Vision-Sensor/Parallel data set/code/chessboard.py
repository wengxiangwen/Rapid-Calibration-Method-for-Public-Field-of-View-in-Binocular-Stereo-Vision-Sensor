import sys

from scipy.io import loadmat
import pyvista as pv
import numpy as np
from ShowAxis_pv import ShowAxis_pv
import cv2
import scipy.io as scio
import matplotlib.pyplot as plt
# def plot_chessboard(plotter):
#     data = loadmat('Calib_Results_left.mat')
#     Rc = {}
#     Tc = {}
#     points_Camerica = {}
#     indices = [0, 5, 6, 11, 12, 17, 18, 23, 24, 29, 30, 35, 36, 41, 42, 47, 48, 53]
#
#     for i in range(1, 15):
#         Rc[i] = data[f'Rc_{i}']
#         Tc[i] = data[f'Tc_{i}']
#         points_Camerica[i] = Rc[i].dot(data['X_1']) + Tc[i]
#
#     for i in range(len(indices) - 1):
#         for j in range(1, 15):
#             line_start = points_Camerica[j].T[indices[i]]
#             line_end = points_Camerica[j].T[indices[i + 1]]
#             plotter.add_lines(np.array([line_start, line_end]), color='g', width=5, label=None)
#             plotter.add_mesh(points_Camerica[j].T, color='w', point_size=10, opacity=1, render_points_as_spheres=True)
# exit()
    # print(points_Camerica1.T)
#在左相机下生成特征点坐标，并对特征点进行画线
def plot_chessboard(plotter):
    data = loadmat('Calib_Results_left.mat')
    Rc_1 = data['Rc_1']
    Rc_2 = data['Rc_2']
    Rc_3 = data['Rc_3']
    Rc_4 = data['Rc_4']
    Rc_5 = data['Rc_5']
    Rc_6 = data['Rc_6']
    Rc_7 = data['Rc_7']
    Rc_8 = data['Rc_8']
    Rc_9 = data['Rc_9']
    Rc_10 = data['Rc_10']
    Rc_11 = data['Rc_11']
    Rc_12 = data['Rc_12']
    Rc_13 = data['Rc_13']
    Rc_14 = data['Rc_14']
    Tc_1 = data['Tc_1']
    Tc_2 = data['Tc_2']
    Tc_3 = data['Tc_3']
    Tc_4 = data['Tc_4']
    Tc_5 = data['Tc_5']
    Tc_6 = data['Tc_6']
    Tc_7 = data['Tc_7']
    Tc_8 = data['Tc_8']
    Tc_9 = data['Tc_9']
    Tc_10 = data['Tc_10']
    Tc_11 = data['Tc_11']
    Tc_12 = data['Tc_12']
    Tc_13 = data['Tc_13']
    Tc_14 = data['Tc_14']
    X_1 = data['X_1']
    X_2 = data['X_2']
    X_3 = data['X_3']
    X_4 = data['X_4']
    X_5 = data['X_5']
    X_6 = data['X_6']
    X_7 = data['X_7']
    X_8 = data['X_8']
    X_9 = data['X_9']
    X_10 = data['X_10']
    X_11 = data['X_11']
    X_12 = data['X_12']
    X_13 = data['X_13']
    X_14 = data['X_14']
    points_Camerica1 = Rc_1.dot(X_1) + Tc_1
    points_Camerica2 = Rc_2.dot(X_2) + Tc_2
    points_Camerica3 = Rc_3.dot(X_3) + Tc_3
    points_Camerica4 = Rc_4.dot(X_4) + Tc_4
    points_Camerica5 = Rc_5.dot(X_5) + Tc_5
    points_Camerica6 = Rc_6.dot(X_6) + Tc_6
    points_Camerica7 = Rc_7.dot(X_7) + Tc_7
    points_Camerica8 = Rc_8.dot(X_8) + Tc_8
    points_Camerica9 = Rc_9.dot(X_9) + Tc_9
    points_Camerica10 = Rc_10.dot(X_10) + Tc_10
    points_Camerica11 = Rc_11.dot(X_11) + Tc_11
    points_Camerica12 = Rc_12.dot(X_12) + Tc_12
    points_Camerica13 = Rc_13.dot(X_13) + Tc_13
    points_Camerica14 = Rc_14.dot(X_14) + Tc_14
    indices = [0, 5, 6, 11, 12, 17, 18, 23, 24, 29, 30, 35, 36, 41, 42, 47, 48, 53]


    # print(points)
    # sys.exit()
    # 遍历每一行和列，计算每个特征点的坐标并添加到列表中
    for i in range(len(indices) - 1):
     line_start1 = points_Camerica1.T[indices[i]]
     line_start2 = points_Camerica2.T[indices[i]]
     line_start3 = points_Camerica3.T[indices[i]]
     line_start4 = points_Camerica4.T[indices[i]]
     line_start5 = points_Camerica5.T[indices[i]]
     line_start6 = points_Camerica6.T[indices[i]]
     line_start7 = points_Camerica7.T[indices[i]]
     line_start8 = points_Camerica8.T[indices[i]]
     line_start9 = points_Camerica9.T[indices[i]]
     line_start10 = points_Camerica10.T[indices[i]]
     line_start11 = points_Camerica11.T[indices[i]]
     line_start12 = points_Camerica12.T[indices[i]]
     line_start13 = points_Camerica13.T[indices[i]]
     line_start14 = points_Camerica14.T[indices[i]]

     line_end1 = points_Camerica1.T[indices[i + 1]]
     line_end2 = points_Camerica2.T[indices[i + 1]]
     line_end3 = points_Camerica3.T[indices[i + 1]]
     line_end4 = points_Camerica4.T[indices[i + 1]]
     line_end5 = points_Camerica5.T[indices[i + 1]]
     line_end6 = points_Camerica6.T[indices[i + 1]]
     line_end7 = points_Camerica7.T[indices[i + 1]]
     line_end8 = points_Camerica8.T[indices[i + 1]]
     line_end9 = points_Camerica9.T[indices[i + 1]]
     line_end10 = points_Camerica10.T[indices[i + 1]]
     line_end11 = points_Camerica11.T[indices[i + 1]]
     line_end12 = points_Camerica12.T[indices[i + 1]]
     line_end13 = points_Camerica13.T[indices[i + 1]]
     line_end14 = points_Camerica14.T[indices[i + 1]]

     # plotter.add_lines(np.array([line_start1, line_end1]), color=[0, 0, 0], width=5, label=None)
     # plotter.add_lines(np.array([line_start2,  line_end2]), color=[255, 255, 255], width=5, label=None)
     # plotter.add_lines(np.array([line_start3, line_end3]), color=[255, 0, 0], width=5, label=None)
     # plotter.add_lines(np.array([line_start4, line_end4]), color=[0, 255, 0], width=5, label=None)
     # plotter.add_lines(np.array([line_start5, line_end5]), color=[0, 0, 255], width=5, label=None)
     # plotter.add_lines(np.array([line_start6, line_end6]), color=[255, 255, 0], width=5, label=None)
     # plotter.add_lines(np.array([line_start7, line_end7]), color=[128, 0, 128], width=5, label=None)
     # plotter.add_lines(np.array([line_start8, line_end8]), color=[154, 205, 50], width=5, label=None)
     # plotter.add_lines(np.array([line_start9, line_end9]), color=[0, 255, 255], width=5, label=None)
     # plotter.add_lines(np.array([line_start10, line_end10]), color=[255, 165, 0], width=5, label=None)
     # plotter.add_lines(np.array([line_start11, line_end11]), color=[0, 100, 0], width=5, label=None)
     # plotter.add_lines(np.array([line_start12, line_end12]), color=[255, 192, 203], width=5, label=None)
     # plotter.add_lines(np.array([line_start13, line_end13]), color=[0, 0, 139], width=5, label=None)
     # plotter.add_lines(np.array([line_start14, line_end14]), color=[255, 215, 0], width=5, label=None)


     plotter.add_mesh(points_Camerica1.T, color=[0, 0, 0], point_size=10, opacity=1, render_points_as_spheres=True)
     plotter.add_mesh(points_Camerica2.T, color=[255, 255, 255], point_size=10, opacity=1, render_points_as_spheres=True)
     plotter.add_mesh(points_Camerica3.T, color=[255, 0, 0], point_size=10, opacity=1, render_points_as_spheres=True)
     plotter.add_mesh(points_Camerica4.T, color=[0, 255, 0], point_size=10, opacity=1, render_points_as_spheres=True)
     plotter.add_mesh(points_Camerica5.T, color=[0, 0, 255], point_size=10, opacity=1, render_points_as_spheres=True)
     plotter.add_mesh(points_Camerica6.T, color=[255, 255, 0], point_size=10, opacity=1, render_points_as_spheres=True)
     plotter.add_mesh(points_Camerica7.T, color=[128, 0, 128], point_size=10, opacity=1, render_points_as_spheres=True)
     plotter.add_mesh(points_Camerica8.T, color=[154, 205, 50], point_size=10, opacity=1, render_points_as_spheres=True)
     plotter.add_mesh(points_Camerica9.T, color=[0, 255, 255], point_size=10, opacity=1, render_points_as_spheres=True)
     plotter.add_mesh(points_Camerica10.T, color=[255, 165, 0], point_size=10, opacity=1, render_points_as_spheres=True)
     plotter.add_mesh(points_Camerica11.T, color=[0, 100, 0], point_size=10, opacity=1, render_points_as_spheres=True)
     plotter.add_mesh(points_Camerica12.T, color=[255, 192, 203], point_size=10, opacity=1, render_points_as_spheres=True)
     plotter.add_mesh(points_Camerica13.T, color=[0, 0, 139], point_size=10, opacity=1, render_points_as_spheres=True)
     plotter.add_mesh(points_Camerica14.T, color=[255, 215, 0], point_size=10, opacity=1, render_points_as_spheres=True)
     # # print(points_Camerica1.T)
if __name__ == '__main__':
    P = pv.Plotter()
    plot_chessboard(P)
    # %% 载入双目结构参数
    data = scio.loadmat('Calib_Results_stereo.mat')  # 载入双目相机标定结果
    R_lr_vec = data['om']  # 左相机到右相机的旋转向量
    R_lr = cv2.Rodrigues(R_lr_vec)[0]  # 旋转向量转旋转矩阵
    t_lr = data['T']  # 左相机到右相机的平移矢量
    ShowAxis_pv(P,70,R_lr,t_lr)
    P.show()
